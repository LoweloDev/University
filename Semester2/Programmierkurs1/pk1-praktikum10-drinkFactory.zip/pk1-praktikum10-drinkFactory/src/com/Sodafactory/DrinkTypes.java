package com.Sodafactory;

public enum DrinkTypes {
    Bier;
}
