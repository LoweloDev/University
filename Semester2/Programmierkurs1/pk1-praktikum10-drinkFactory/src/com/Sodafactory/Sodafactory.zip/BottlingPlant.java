package com.Sodafactory;

import static java.lang.Thread.sleep;

record BottlingPlant(Conveyor conveyor) implements Runnable {
    @Override
    public void run() {
        while(true) {
            synchronized (conveyor) {
                while(conveyor.isOverloaded()){
                    System.out.println("true");
                    try {
                        conveyor.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
//            while (!conveyor.isOverloaded()) {
                Bottle bottle = new Bottle();
                bottle.setDrinkType(DrinkTypes.Bier);

                // useless block Arbeitsgeschwindigkeitssimulation in Aufgabe verlangt
                try {
                    sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                // simulation ente

                conveyor.load(bottle);
                conveyor.notifyAll();
                System.out.println("Befüllt");
//            }

            }
        }

    }
}
